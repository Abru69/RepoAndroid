package com.example.autosms.BroadcastReceiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.telephony.TelephonyManager
import android.telephony.SmsManager
import android.util.Log

class CallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // Verifica si la acción es un cambio en el estado del teléfono
        if (intent.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            Log.d("CallReceiver", "Recibiendo evento de llamada")

            val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)

            // Verifica si el estado es "RINGING" (llamada entrante)
            if (state == TelephonyManager.EXTRA_STATE_RINGING) {
                val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                Log.d("CallReceiver", "Llamada entrante de: $incomingNumber")

                // Obtener número y mensaje guardados en SharedPreferences
                val (targetNumber, message) = getSavedData(context)

                // Si no hay datos guardados, no hacer nada
                if (targetNumber.isNullOrEmpty() || message.isNullOrEmpty()) {
                    Log.d("CallReceiver", "Número o mensaje no configurados, no se envía SMS")
                    return
                }

                // Verifica si el número coincide con el ingresado por el usuario
                if (incomingNumber == targetNumber) {
                    sendSms(targetNumber, message)
                    Log.d("CallReceiver", "SMS enviado a: $targetNumber con el mensaje: $message")
                }
            }
        }
    }

    private fun sendSms(phoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Log.d("CallReceiver", "SMS enviado correctamente")
        } catch (e: Exception) {
            Log.e("CallReceiver", "Error al enviar SMS: ${e.message}")
        }
    }

    private fun getSavedData(context: Context): Pair<String?, String?> {
        val sharedPreferences: SharedPreferences = context.getSharedPreferences("AutoSMSPrefs", Context.MODE_PRIVATE)
        val phoneNumber = sharedPreferences.getString("targetNumber", null)
        val message = sharedPreferences.getString("smsMessage", null)
        return Pair(phoneNumber, message)
    }
}
